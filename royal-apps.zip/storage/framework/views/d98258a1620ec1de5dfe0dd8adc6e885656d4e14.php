<?php $__env->startSection('main-container'); ?>

<div class="container">
    <div class="form__tabs__wrap">
        <h1>Add Author</h1>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if((session('message'))): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('post.author')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form__grp">
                <label for="email">First Name</label>
                <input type="text" id="first_name" name="first_name" placeholder="Your first name" class="form-control">
            </div>
            <div class="form__grp">
                <label for="email">Last Name</label>
                <input type="text" id="last_name" name="last_name" placeholder="Your last name" class="form-control">
            </div>
            <div class="form__grp">
                <label for="email">DOB</label>
                <input type="date" id="birthday" name="birthday" placeholder="Your birthday" class="form-control">
            </div>
            <div class="form__grp">
                <label for="email">bio</label>
                <input type="text" id="biography" name="biography" placeholder="Your biography" class="form-control">
            </div>
            <div class="form__grp">
                <label for="email">Gender</label>
                <select class="form-control" name="gender">
                    <option value="male">Male</option>
                    <option value="female">FeMale</option>
                </select>
            </div>
            <div class="form__grp">
                <label for="email">Place of birth</label>
                <input type="text" id="place_of_birth" name="place_of_birth" placeholder="Your place of birth"
                    class="form-control">
            </div>
            <div class="create__btn">
                <button type="submit" class="cmn--btn">
                    <span>Add</span>
                </button>
            </div>

        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/authors/add.blade.php ENDPATH**/ ?>