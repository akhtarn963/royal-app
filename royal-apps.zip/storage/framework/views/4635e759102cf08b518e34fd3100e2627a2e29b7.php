<?php $__env->startSection('main-container'); ?>

<div class="container">
    <div class="form__tabs__wrap">
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if((session('message'))): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('login.post')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form__grp">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Your email address" class="form-control"
                    required autofocus>
            </div>
            <div class="form__grp">
                <label for="toggle-password9">Password</label>
                <input id="toggle-password9" type="password" placeholder="Your Password" name="password"
                    class="form-control" required>
                <span id="#password" class="fa fa-fw fa-eye field-icon toggle-password9"></span>
            </div>
            <div class="create__btn">
                <button type="submit" class="cmn--btn">
                    <span>Login</span>
                </button>
            </div>

        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/login.blade.php ENDPATH**/ ?>