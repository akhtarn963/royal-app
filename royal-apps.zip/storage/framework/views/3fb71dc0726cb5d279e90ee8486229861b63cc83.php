<?php $__env->startSection('main-container'); ?>

<div class="container">
    <div class="form__tabs__wrap">
        <h1>Authors List</h1>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if((session('message'))): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <a href="<?php echo e(route('add-new-author')); ?>"><button type="button" class="btn">Add New</button></a>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <td>First Name</td>
                    <td>Last Name</td>
                    <td>Gender</td>
                    <td>Birth Place</td>
                </tr>
            </thead>
            <tbody>
                <?php if(count($authors) > 0): ?>
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data['first_name']); ?></td>
                    <td><?php echo e($data['last_name']); ?></td>
                    <td><?php echo e($data['gender']); ?></td>
                    <td><?php echo e($data['place_of_birth']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/authors.blade.php ENDPATH**/ ?>