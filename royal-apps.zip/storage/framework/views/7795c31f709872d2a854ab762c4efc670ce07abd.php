</body>

</html><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/layouts/footer.blade.php ENDPATH**/ ?>