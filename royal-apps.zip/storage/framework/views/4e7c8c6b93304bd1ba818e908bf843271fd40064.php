<?php $__env->startSection('main-container'); ?>

<div class="container">
    <div class="form__tabs__wrap">
        <h1>Authors List</h1>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if((session('message'))): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>

        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <td>First Name</td>
                    <td>Last Name</td>
                    <td>Gender</td>
                    <td>Birth Place</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($author['first_name']); ?></td>
                    <td><?php echo e($author['last_name']); ?></td>
                    <td><?php echo e($author['gender']); ?></td>
                    <td><?php echo e($author['place_of_birth']); ?></td>
                </tr>
                <tr>
                    <td>
                        <h3>Book List</h3>
                    </td>
                </tr>
                <?php if(count($author['books']) > 0): ?>
                <?php $__currentLoopData = $author['books']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <tr>
                    <td><?php echo e($data['title']); ?></td>
                    <td><?php echo e($data['release_date']); ?></td>
                    <td><?php echo e($data['number_of_pages']); ?></td>
                    <td><a href="<?php echo e(route('author.book.delete',[$author['id'],$data['id']])); ?>">Delete</a></td>
                </tr>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/authors/view.blade.php ENDPATH**/ ?>