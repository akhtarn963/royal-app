<?php $__env->startSection('main-container'); ?>

<div class="container">

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <?php if((session('error'))): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <h3>Inverted Navbar</h3>
    <p>An inverted navbar is black instead of gray.</p>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/index.blade.php ENDPATH**/ ?>