<!DOCTYPE html>
<html lang="en">

<head>
    <title>Royal Apps Test</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Royal-apps</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <?php if(session('is_loggedin')): ?>
                <li><a href="<?php echo e(route('authors.index')); ?>">Authors</a></li>
                <li><a href="<?php echo e(route('books.index')); ?>">Books</a></li>
                <li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
                <?php else: ?>
                <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if(session('is_loggedin')): ?>
            <div style="float:right; color:#FFF;">
                <h4><?php echo e(session('user_name')); ?></h4>
            </div>
            <?php endif; ?>
        </div>
    </nav><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/layouts/header.blade.php ENDPATH**/ ?>