<?php $__env->startSection('main-container'); ?>

<div class="container">
    <div class="form__tabs__wrap">
        <h1>Books List</h1>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if((session('message'))): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <td>Title</td>
                    <td>Release Date</td>
                    <td>Number of pages</td>
                </tr>
            </thead>
            <tbody>
                <?php if(count($books) > 0): ?>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data['title']); ?></td>
                    <td><?php echo e($data['release_date']); ?></td>
                    <td><?php echo e($data['number_of_pages']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WinNMP\WWW\Inteview Test\royal-apps\resources\views/books.blade.php ENDPATH**/ ?>